# -*- coding: utf-8 -*-

from . import student_information
from . import student_standard
from . import student_subject
from . import professor_record