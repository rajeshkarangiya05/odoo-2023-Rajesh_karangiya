# -*- coding: utf-8 -*-

from odoo import models, fields, api, _

class ProfessorRecord(models.Model):
    _name = "professor.record"

    name = fields.Char(string="Name", required=True, help="")
    subject_id = fields.Many2one('student.subject', string='Subject')
    student_id = fields.Many2one('student.information', string='Student')
    
        
