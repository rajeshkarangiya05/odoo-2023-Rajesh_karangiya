# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from odoo.exceptions import ValidationError

class StudentStandard(models.Model):
    _name = "student.standard"

    name = fields.Char(string="Name", required=True, help="")
    student_ids =fields.One2many('student.information','standard_id', string="Student")
    number = fields.Integer('Number')

    @api.model
    def create(self, vals):
        print("\n\n\n vals.get('number')", vals.get('number'))
        if vals.get('number') and vals.get('number') < 2:
            raise ValidationError("Please number that is greater than 2!!!")

        stand = super(StudentStandard, self).create(vals)
        print(">>>",stand)
        student_ls = [{'name': 'Amit', 'roll_no': 7}, {'name': 'Viren', 'roll_no': 1}, {'name': 'Mukund', 'roll_no': 2}]
        vals = {'name': 'Amit', 'roll_no': 7}
        student = self.env['student.information'].create(vals)
        print("\n\n\n\n student", student, stand)
        print("<<<<<<",stand.id)
        student.standard_id = stand.id
        return stand
    def write(self, vals):
    
        records = self.env['professor.record'].search([('name', '=', 'Amit'), (), ()])
        records_count = self.env['professor.record'].search_count([])
        print("\n\n\n records ::::::::::", records)
        if 'address' in vals:
            raise ValidationError("You cannot change address for this student!")
        res = super(StudentInformation, self).write(vals)
        return res
    
