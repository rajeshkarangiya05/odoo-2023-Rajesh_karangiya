# -*- coding: utf-8 -*-

from odoo import models, fields, api, _

class StudentStandard(models.Model):
    _name = "student.standard"

    name = fields.Char(string="Name", required=True, help="")
    student_ids =fields.One2many('student.information','standard_id', string="Student")
    
